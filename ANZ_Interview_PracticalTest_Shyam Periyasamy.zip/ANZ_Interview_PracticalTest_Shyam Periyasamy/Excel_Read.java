

import java.io.File;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * <p>
 * This class and its methods will perform all the spread sheet funtions of ANZ NZ - Mortgage - Repayments and Borrowing 
 * calculators testing
 * This suite is created as part of ANZ NZ interview process and only performs AMOUNT FILED validation in 
 * Repayments Calculator and Borrowing Calculator. The navigation from one page to another page done based on
 * very minimal WebElement Validation.
 * <p>
 * 
 * @author Shyam Periyasamy
 *
 */

public class Read_XL 
{

		public String weblink () throws Exception 
	{
		File src=new File("D:\\Eclipse\\Work Space\\ANZ_Interview_task\\ANZ InterView TestData\\ANZ_InterView_TestData.xlsx");
		
		FileInputStream fis=new FileInputStream(src);
		
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
		XSSFSheet sn=wb.getSheet("ANZ_Mortgage_LinkDetails");
		
		String weblink=sn.getRow(1).getCell(1).getStringCellValue(); 
		
		wb.close();
		
		return (weblink) ;
	}

}