

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


/**
 * <p>
 * This Class contains all the needful functions as methods which we need to perform our testing in TestNG
 * please refer each method for the use of those methods.
 * This suite is created as part of ANZ NZ interview process and only performs AMOUNT FILED validation in 
 * Repayments Calculator and Borrowing Calculator. The page identification was done base based on very
 * minimal WebElement Validation. Used POM to validate Main Page - logon button is displayed and enabled as 
 * a proof of concept
 * <p>
 * 
 * @driver - declared as common for this class
 *  
 * @author Shyam Periyasamy
 *
 *
 */

public class ANZ_Mortgage_Common_Methods 

{


	public static WebDriver driver;
	
	/**
	 * <p>
	 * This method will open a chrome browser
	 * <p>
	 * @path of chromedriver.exe
	 * @throws Exception
	 */
	
	public static void Open_Chrome() throws Exception
	
	{
		System.setProperty("webdriver.chrome.driver", "D:\\selenium-java-3.5.0\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	/**
	 * This method will call Read_XL class and its method to fetch the Website link
	 * @return from Read_XL
	 * @throws Exception
	 */
	
	public static void Navigate_ANZ_WebSite() throws Exception
	
	{
		Read_XL Home_page=new Read_XL();
		String ANZ_Home_Page = Home_page.weblink();
		driver.get(ANZ_Home_Page);
	}
	
	/**
	 * This method will validate and confirm the existing page is ANZ NZ Website Home page or not, if the existing page is 
	 * ANZ NZ Website home page then clicks products tab
	 * @throws IOException
	 */
	public static void Validate_Home_Page() throws IOException
	
	{
		
		ANZ_NZ_Wesite_MainPage HomePage=new ANZ_NZ_Wesite_MainPage(driver);
		boolean Logon_Is_Enabled = HomePage.Logon_Is_Enabled();
		boolean Logon_Is_Displayed = HomePage.Logon_Is_Displayed();
		//boolean Logon_Is_Enabled = driver.findElement(By.xpath("//input[@id=\"button_logon\"]")).isEnabled();
		//boolean Logon_Is_Displayed = driver.findElement(By.xpath("//input[@id=\"button_logon\"]")).isDisplayed();
		
		if (Logon_Is_Enabled && Logon_Is_Displayed) //if true then click personal
			{
				driver.findElement(By.xpath(".//*[@id='tabs-personal']/a/span[1]")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
				boolean Product_Mortage_Enabled = driver.findElement(By.xpath(".//*[@id='tabs-personal']/div/div/div[1]/ul/li[4]/a/span[1]")).isEnabled();
				
					if (Product_Mortage_Enabled)
						{	
							driver.findElement(By.xpath(".//*[@id='tabs-personal']/div/div/div[1]/ul/li[4]/a/span[1]")).click();
							driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
						}
					else
						{
							System.out.println("Mortgage button didn't displayed");
						}
				
			}
		else
			{
				System.out.println("Logon Button is not Enabled and Displayed");
			}
	}
	
	/**
	 * This method will validate and confirm the existing page is ANZ NZ Website - Mortgage page or not, if the existing
	 * page is ANZ NZ Mortgage page then clicks Mortgage Weblink to make visible of sub-links under this links
	 * @throws IOException
	 */
	public static void Mortgage_page_validation() throws IOException
	{
		boolean Buy_My_First_Home = driver.findElement(By.xpath(".//*[@id='contentWrapper']/div[3]/div[1]/p/a/img")).isDisplayed();
		
		if (Buy_My_First_Home)
			{
				System.out.println("Mortgage Page is Displayed");
				driver.findElement(By.xpath(".//*[@id='leftnav']/li[11]/a[2]")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
		else
			{
			System.out.println("Mortgage Page didnot Displayed");
			}
	}
	
	/**
	 * This method will click the Repay Calculator link if the Repay Calculator link is visible
	 * @throws IOException
	 */
	
	public static void Repay_Calc_link_Click() throws IOException
	{
		boolean Repay_Calc = driver.findElement(By.xpath(".//*[@id='leftnav']/li[11]/ul/li[1]/a[2]")).isDisplayed();
		
		if (Repay_Calc)
			{
				System.out.println("Repay Calculator link displayed in Mortgage Page");
				driver.findElement(By.xpath(".//*[@id='leftnav']/li[11]/ul/li[1]/a[2]")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			}
		else
			{
				System.out.println("Repay Calculator link didnot displayed in Mortgage Page");
			}

	}
	
	/**
	 * This method will click the Borrow Calculator link if the Repay Calculator link is visible
	 * @throws IOException
	 */
	
	public static void Borrow_Calc_link_Click() throws IOException
	{
		boolean Repay_Calc = driver.findElement(By.xpath(".//*[@id='leftnav']/li[11]/ul/li[2]/a[2]")).isDisplayed();
		
		if (Repay_Calc)
			{
				System.out.println("Barrow Calculator link displayed in Mortgage Page");
				driver.findElement(By.xpath(".//*[@id='leftnav']/li[11]/ul/li[2]/a[2]")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			}
		else
			{
				System.out.println("Repay Calculator link didnot displayed in Mortgage Page");
			}

	}
	
	/**
	 * This method validate and confirms that the existing page is Repayments Calculator 
	 * @throws IOException
	 */
	
	public static void Repay_Calc() throws IOException
	{
		boolean Barrow_Calc_Loan_amount = driver.findElement(By.xpath(".//*[@id='LoanAmount']")).isDisplayed();
		
		if (Barrow_Calc_Loan_amount)
			{
				System.out.println("Repay Calculator lanched successfully");
			}
		else
			{
				System.out.println("Repay Calculator didnot lanched");
			}
	}
	
	/**
	 * This method validate and confirms that the existing page is Barrowing Calculator page
	 * @throws IOException
	 */
	
	public static void Barrow_Calc() throws IOException
	{
		boolean Barrow_Calc_Loan_amount = driver.findElement(By.xpath(".//*[@id='Income_AnnualHousehold']")).isDisplayed();
		
		if (Barrow_Calc_Loan_amount)
			{
				System.out.println("Repay Calculator lanched successfully");
			}
		else
			{
				System.out.println("Repay Calculator didnot lanched");
			}
	}	
	
	/**
	 * This method will enter a given value thru the param into loan amount field and check for error message, if error message does not appear 
	 * this method will fail the test case 
	 * @param amt
	 * @throws IOException
	 */
	
	public static void Repay_Calc_Loan_Amount_FieldValidation_Negative(String amt) throws IOException
	{
		driver.findElement(By.xpath(".//*[@id='LoanAmount']")).sendKeys(amt); //write 4999 into the Loan Amount field
		driver.findElement(By.xpath(".//*[@id='calculatorInner']/form/fieldset/input[3]")).click(); //Click Calculate button to move the cursor away from Loan Amount text box
		
		try 
			{
				driver.findElement(By.xpath(".//*[@id='calculatorInner']/form/fieldset/div[2]/div/span[2]/span")).isDisplayed();
				System.out.println("Error message expected for below 5000 and above 50000000"+amt);
			}
		catch(NoSuchElementException e) 
			{
			System.out.println("Error message not expected for above 5000 and below 50000000"+amt);
			}

	}
	
	/**
	 * This method will enter a given value thru the param into loan amount field and check for error message, if error message does not appear 
	 * this method will fail the test case 
	 * @param amt
	 * @throws IOException
	 */
	
	public static void Barrow_Calc_Loan_Amount_FieldValidation_Negative(String amt) throws IOException
	{
		driver.findElement(By.xpath(".//*[@id='Income_AnnualHousehold']")).sendKeys(amt); 
		driver.findElement(By.xpath(".//*[@id='baseSubmit']")).click(); 
		
		try 
			{
				driver.findElement(By.xpath(".//*[@id='js-simpleFormWrapper']/div[2]/span/span")).isDisplayed();
				System.out.println("Error message expected for negative numbers or other then numbers"+amt);
			}
		catch(NoSuchElementException e) 
			{
			System.out.println("Error message not expected for number between 0 to 9999999"+amt);
			}

	}
	
	/**
	 * This method will enter a given value thru the param into loan amount field and check for positive message, if positive message does not appear 
	 * this method will fail the test case
	 * @param amt
	 */
	
	public static void Repay_Calc_Loan_Amount_FieldValidation_Positive(String amt)
	{
		driver.findElement(By.xpath(".//*[@id='LoanAmount']")).sendKeys(amt); 
		driver.findElement(By.xpath(".//*[@id='calculatorInner']/form/fieldset/input[3]")).click();
		
		try
		{
			driver.findElement(By.xpath(".//*[@id=\"calculatorInner\"]/div/div/div[2]/div[1]/label")).isDisplayed();
			System.out.println("Error message not expected for above 5000 and below 50000000"+amt);
		}
	catch(NoSuchElementException e)
		{
			System.out.println("Error message expected for below 5000 and above 50000000"+amt);
		}

	}
	
	/**
	 * This method will enter a given value thru the param into loan amount field and check for positive message, if positive message does not appear 
	 * this method will fail the test case
	 * @param amt
	 */
	
	public static void Barrow_Calc_Loan_Amount_FieldValidation_Positive(String amt)
	{
		driver.findElement(By.xpath(".//*[@id='Income_AnnualHousehold']")).sendKeys(amt); 
		driver.findElement(By.xpath(".//*[@id='baseSubmit']")).click(); 
		
		try
		{
			driver.findElement(By.xpath(".//*[@id='js-affordabilityResultPartial']/div/div/div[2]/div/p[1]")).isDisplayed();
			System.out.println("Error message not expected for number between 0 to 9999999"+amt);
		}
	catch(NoSuchElementException e)
		{
			System.out.println("Error message expected for negative numbers or other then numbers"+amt);
		}

	}
	
	/**
	 * This method will click the reset button in the Repayments Calculator page
	 */
	
	public static void Repay_Calc_Reset_Button_Click()
	{
		boolean Repay_Reset_button = driver.findElement(By.xpath(".//*[@id=\"RepaymentCalculatorOuter\"]/div[1]/div/div/div/div[1]/a/i")).isDisplayed();
		if (Repay_Reset_button)
			{
				driver.findElement(By.xpath(".//*[@id=\"RepaymentCalculatorOuter\"]/div[1]/div/div/div/div[1]/a/i")).click();
				System.out.println("Restting Repay Calculator");
				boolean Repay_Reset_Button_warring = driver.findElement(By.xpath(".//*[@id=\"ui-dialog-title-dialog-confirm\"]")).isDisplayed();
					if (Repay_Reset_Button_warring)
					{
						driver.findElement(By.xpath("./html/body/div[9]/div[3]/div/button[1]/span")).click();
						System.out.println("Repay Calculator Resetted");
					}
			}
	}
	
	/**
	 * This method will close the browser
	 * @throws IOException
	 */
	
	public static void close_browser() throws IOException
	{
		driver.close();
		System.out.println("Browser closed successfully");
	}
	
}
