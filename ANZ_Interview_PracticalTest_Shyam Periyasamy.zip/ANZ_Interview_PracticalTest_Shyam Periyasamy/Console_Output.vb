PASSED: Test_Repayment_Calculator_LoanAmount_Field_Validation_LessThanMinimum
        This test is to validate the Repayments calculator - loan amount field throws error if we enter less than 5000
PASSED: Test_Repayment_Calculator_LoanAmount_Field_Validation_EqualToMinimum
        This test is to validate the Repayments calculator - loan amount field is accepting without any error if the value is 5000 to 50000000 and display the repay value
PASSED: Test_Barrowing_Calculator_LoanAmount_Field_Validation_LessThanMinimum
        This test is to validate the Barrowing calculator - Income amount field throws error if we enter negative numbers or other than numbers
PASSED: Test_Barrowing_Calculator_LoanAmount_Field_Validation_positive_value
        This test is to validate the barrowing calculator - Income amount field is accepting the value and display the barrowing value

===============================================
    Default test
    Tests run: 4, Failures: 0, Skips: 0
===============================================


===============================================
Default suite
Total tests run: 4, Failures: 0, Skips: 0
===============================================