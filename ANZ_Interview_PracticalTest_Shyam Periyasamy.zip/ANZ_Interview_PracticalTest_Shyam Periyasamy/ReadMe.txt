This is a smoke test of ANZ NZ - Martgage Calculator - Repayments and Borrowing Calculator - Amount fields
This suite created as part of ANZ NZ interview process