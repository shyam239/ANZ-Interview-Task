import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * <p>
 * This suite is created as part of ANZ NZ interview process and only performs AMOUNT FILED validation in 
 * Repayments Calculator and Borrowing Calculator. The navigation from one page to another page done based on
 * very minimal WebElement Validation.
 * This is a Hybrid FrameWork mix of method driven and data driven framework
 * And also test data is hard coded in each test case since we explained one functionality (Website - name)
 * as a proof of data driven framework
 * Each test case has its own description, please refer to that for more details about test case
 * 
 * @author Shyam Periyasamy
 *
 */

public class TestNG_ANZ_Morgage_Amount_Validation_Smoke_TestSuite 
{

/**
 * This method will perform the common functionalities prior to perform each test script.
 * Common functionalities like open browser, pass the ANZ NZ WebSite URL and navigate till Mortgage page. 	
 *  
 * @throws Exception
 */
	
@BeforeMethod(description = "This before method will perfrom the action till bring it to Mortgage page then based on the test case we will call needed calculator")

public void Pre_test_navigation() throws Exception
{
	ANZ_Mortgage_Common_Methods.Open_Chrome();
	ANZ_Mortgage_Common_Methods.Navigate_ANZ_WebSite();
	ANZ_Mortgage_Common_Methods.Validate_Home_Page();
	ANZ_Mortgage_Common_Methods.Mortgage_page_validation();
}

@Test(priority=1,description = "This test is to validate the Repayments calculator - loan amount field throws error if we enter less than 5000" )

public void Test_Repayment_Calculator_LoanAmount_Field_Validation_LessThanMinimum() throws Exception
{

	String amt = "4999";
	
	ANZ_Mortgage_Common_Methods.Repay_Calc_link_Click();
	ANZ_Mortgage_Common_Methods.Repay_Calc();
	ANZ_Mortgage_Common_Methods.Repay_Calc_Loan_Amount_FieldValidation_Negative(amt);
	
}

@Test(priority=2,description = "This test is to validate the Repayments calculator - loan amount field is accepting without any error if the value is 5000 to 50000000 and display the repay value" )

public void Test_Repayment_Calculator_LoanAmount_Field_Validation_EqualToMinimum() throws Exception

{
	String amt = "5000";
	
	ANZ_Mortgage_Common_Methods.Repay_Calc_link_Click();
	ANZ_Mortgage_Common_Methods.Repay_Calc();
	ANZ_Mortgage_Common_Methods.Repay_Calc_Loan_Amount_FieldValidation_Positive(amt);

}

@Test(priority=3,description="This test is to validate the Barrowing calculator - Income amount field throws error if we enter negative numbers or other than numbers")

public void Test_Barrowing_Calculator_LoanAmount_Field_Validation_LessThanMinimum() throws Exception
{
	String amt = "-999";
	
	ANZ_Mortgage_Common_Methods.Borrow_Calc_link_Click();
	ANZ_Mortgage_Common_Methods.Barrow_Calc();
	ANZ_Mortgage_Common_Methods.Barrow_Calc_Loan_Amount_FieldValidation_Negative(amt);
}

@Test(priority=4,description="This test is to validate the barrowing calculator - Income amount field is accepting the value and display the barrowing value")

public void Test_Barrowing_Calculator_LoanAmount_Field_Validation_positive_value() throws IOException
{
	String amt = "99999";
	
	ANZ_Mortgage_Common_Methods.Borrow_Calc_link_Click();
	ANZ_Mortgage_Common_Methods.Barrow_Calc();
	ANZ_Mortgage_Common_Methods.Barrow_Calc_Loan_Amount_FieldValidation_Positive(amt);
}

/**
 * This method will perform the common functionalities after perform each test script.
 * Common functionalities like close browser. 	
 *  
 * @throws Exception
 */

@AfterMethod(description = "This after method will close the browser")
public void after_test_function() throws IOException
{
	ANZ_Mortgage_Common_Methods.close_browser();
}
	
}

