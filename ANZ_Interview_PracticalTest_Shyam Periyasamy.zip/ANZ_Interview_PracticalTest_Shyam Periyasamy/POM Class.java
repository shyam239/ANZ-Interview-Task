import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



/**
 * 
 * This class is a example of POM this will contain only the main page objects of ANZ NZ web page
 * @author Shyam Periyasamy
 *
 */
public class ANZ_NZ_Wesite_MainPage 
{
	WebDriver driver;
	By Logon_Button=By.xpath(".//*[@id='tabs-personal']/a/span[1]");
	
	public ANZ_NZ_Wesite_MainPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public boolean Logon_Is_Enabled()
	{
		return driver.findElement(Logon_Button).isEnabled();
	}
	
	public boolean Logon_Is_Displayed()
	{
		return driver.findElement(Logon_Button).isDisplayed();
	}
	
	
}
